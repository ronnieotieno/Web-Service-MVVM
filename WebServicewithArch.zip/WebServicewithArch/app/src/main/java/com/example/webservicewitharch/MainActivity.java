package com.example.webservicewitharch;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class MainActivity extends AppCompatActivity {
    PicsViewModel picsViewModel;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final PicsAdapter adapter = new PicsAdapter();
        recyclerView.setAdapter(adapter);

        picsViewModel = ViewModelProviders.of((FragmentActivity) context).get(PicsViewModel.class);
        picsViewModel.getAllPictures().observe((LifecycleOwner) this, new Observer<List<Pictures>>() {
            @Override
            public void onChanged(List<Pictures> pictures) {

                adapter.setPics(pictures);

            }
        });
    }
}
